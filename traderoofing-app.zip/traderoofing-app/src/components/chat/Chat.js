import { CircularProgress } from "@mui/material";
import { formatDistance } from "date-fns";
import React, { useState } from "react";
import { useEffect } from "react";
import { io } from "socket.io-client";
import Global from "../Global";

const socket=io(Global.ws);


const Chat = ({userChat,chatArray,serviceId})=>{
    const [chat, setChat]=useState(null);
    let url= Global.url;


    useEffect(()=>{
        setChat(chatArray);
    },[])

   

    if(chat===null){
        return(
            <CircularProgress></CircularProgress>
        )
    }
    return(
        <div className="description-detail">
            <div className="table-h-label">Notes</div>
            {
                chat.map((item,i)=>(

                    <div className={item.user===userChat.name?"note-item":"note-item receive"} key={i}>
                        <div className="table-h-label">{item.user}</div>
                        <div className="table-r-label">{item.message}</div>
                        <div className="table-r-label time">{formatDistance(new Date(),new Date(item.date))}</div>
                    </div>
                ))
            }
                
        </div>
    )
}
export default Chat;