import React, { useEffect, useState } from "react";
import './SelectorBig.css';

const SelectorBig =({items,defaultLabel, onSelectItem, selectedItem})=>{
    const [showList, setShowList] = useState(false);
    return(
        <div
            className="selector-products"
            onClick={(e)=>{
                setShowList(!showList)
            }}
            onMouseLeave={(e)=>{
                setShowList(false)
            }}
        >
            <div className={selectedItem?"selected-item":"default-item"}>{selectedItem?selectedItem:defaultLabel}</div>
            {
                showList&&
                <div className="selector-list">
                    <ul className="selector-scroll">
                    {
                        items!==undefined&&
                        items.map((item,i)=>(
                            <div 
                                key={i} 
                                value={item.name} 
                                className="selectedVal"
                                onClick={()=>{
                                    onSelectItem(item);
                                }}
                            >{item.label}</div>
                        ))
                    }
                    </ul>
                </div>
            }
            <div className="border-selected" style={!showList?{border:'1px solid #00000020'}:{border:'2px solid #26d07c'}}></div>
           
        </div>
        )
}

export default SelectorBig;