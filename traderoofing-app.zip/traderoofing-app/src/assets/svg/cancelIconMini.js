import React, {useState}from 'react';

const CancelIconMini = () => {
   const [fill, setFill]= useState('#101820');

    return(
        <svg width="26" height="26" viewBox="0 0 32 33" fill="none" xmlns="http://www.w3.org/2000/svg" onMouseEnter={()=>{setFill('white')}}  onMouseLeave={()=>{setFill('#101820')}}>
            <path d="M16 32.585C24.8366 32.585 32 25.4215 32 16.585C32 7.7484 24.8366 0.584961 16 0.584961C7.16344 0.584961 0 7.7484 0 16.585C0 25.4215 7.16344 32.585 16 32.585Z" fill="#FF5757"/>
            <path d="M19.6691 12.916L12.3311 20.254L19.6691 12.916Z" fill="#FF5757"/>
            <path d="M19.6691 20.254L12.3311 12.916M19.6691 12.916L12.3311 20.254" stroke={fill} strokeWidth="2" strokeLinecap="round"/>
        </svg>
        
    )
};

export default CancelIconMini;