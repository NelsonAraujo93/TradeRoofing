import React, {useState}from 'react';

const EditIcon = (fillColor) => {
   const [fill, setFill]= useState('#101820');

    return(
        <svg width="33" height="32" viewBox="0 0 33 32" fill="none" xmlns="http://www.w3.org/2000/svg" onMouseEnter={()=>{setFill('white')}}  onMouseLeave={()=>{setFill('#101820')}}>
            <path d="M16.5 32C25.3366 32 32.5 24.8366 32.5 16C32.5 7.16344 25.3366 0 16.5 0C7.66344 0 0.5 7.16344 0.5 16C0.5 24.8366 7.66344 32 16.5 32Z" fill="#26D07C"/>
            <path d="M20.2634 9.20903C20.4622 9.01024 20.6982 8.85256 20.9579 8.74498C21.2176 8.6374 21.496 8.58203 21.7771 8.58203C22.0582 8.58203 22.3366 8.6374 22.5963 8.74498C22.856 8.85256 23.092 9.01024 23.2908 9.20903C23.4896 9.40781 23.6473 9.6438 23.7548 9.90352C23.8624 10.1632 23.9178 10.4416 23.9178 10.7227C23.9178 11.0038 23.8624 11.2822 23.7548 11.5419C23.6473 11.8017 23.4896 12.0376 23.2908 12.2364L13.0733 22.4539L8.91064 23.5892L10.0459 19.4265L20.2634 9.20903Z" stroke={fill} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
    )
};

export default EditIcon;