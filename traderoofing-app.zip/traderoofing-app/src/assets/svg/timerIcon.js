import React, {useEffect, useState}from 'react';
import { useNavigate } from 'react-router-dom';
const IconTime = (fillScale, active) => {
    const [fill, setFill]= useState(null);
    useEffect(() => {
        if(fillScale.fillScale>=4){
            setFill('#26D07C')
        } else if(fillScale.fillScale===3){
            setFill('#F4E12E')
        } else if(fillScale.fillScale<=2){
            setFill('#FB2525')
        }

    },[])
    let history = useNavigate();
    return(

        <svg width="44" height="44" viewBox="0 0 44 44" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path d="M21.7341 40.7221C32.2047 40.7221 40.6928 32.234 40.6928 21.7634C40.6928 11.2928 32.2047 2.80469 21.7341 2.80469C11.2635 2.80469 2.77539 11.2928 2.77539 21.7634C2.77539 32.234 11.2635 40.7221 21.7341 40.7221Z" stroke={fill} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
        <path d="M27.422 29.3464L22.8454 24.7698C22.1342 24.0589 21.7346 23.0946 21.7344 22.089V10.3877" stroke={fill} strokeWidth="5" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>
        
        
    )
};

export default IconTime;