import React, {useState}from 'react';

import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Swal from 'sweetalert2';
import { useNavigate } from 'react-router-dom';

const UserICon = (props) => {
   const [fill, setFill]= useState(props.fill);
   const [activeColor, setActiveColor]= useState(false);
   const [anchorEl, setAnchorEl] = React.useState(null);
   
   let history = useNavigate();
   const open = Boolean(anchorEl);
   const handleClick = (event) => {
     setAnchorEl(event.currentTarget);
     setActiveColor(true);
     setFill('white');
   };
   const handleClose = () => {
     setAnchorEl(null);
     setActiveColor(false);
     setFill('black');
   };
   const logOut = () =>{
    //remove tokenSesion
    localStorage.removeItem('userSesion');
     Swal.fire({
        title: '<div class="big-square"></div>'+
        '<div class="little-square"></div>'+
        '<div class="bg-title-pop"><div class="list-label pop absolute-center">Sesión cerrada</div></div>',
    }).then(()=>{
        history('/');
        window.location.reload();
    })
    //redirectTo Home
}
    return(
        <div style={{width:32, height:32, position:"relative"}}>
         
            <svg 
                width="33" 
                height="33" 
                viewBox="0 0 33 33" 
                fill={fill} 
                xmlns="http://www.w3.org/2000/svg" 
                onMouseEnter={()=>{setFill('white')}}  
                onMouseLeave={()=>{if(!activeColor){setFill('black')}}}
                onClick={handleClick}
            >
                <path d="M16.8301 32.5C25.6666 32.5 32.8301 25.3366 32.8301 16.5C32.8301 7.66344 25.6666 0.5 16.8301 0.5C7.99352 0.5 0.830078 7.66344 0.830078 16.5C0.830078 25.3366 7.99352 32.5 16.8301 32.5Z" fill="#26D07C"/>
                <path d="M25.9683 23.8179C24.7743 21.7607 22.9222 20.1656 20.7107 19.2898C21.7963 18.4756 22.5983 17.3404 23.0029 16.0451C23.4076 14.7498 23.3944 13.3599 22.9653 12.0725C22.5361 10.7851 21.7128 9.66533 20.6119 8.87184C19.511 8.07835 18.1883 7.65137 16.8313 7.65137C15.4742 7.65137 14.1516 8.07835 13.0507 8.87184C11.9498 9.66533 11.1264 10.7851 10.6973 12.0725C10.2682 13.3599 10.255 14.7498 10.6597 16.0451C11.0643 17.3404 11.8663 18.4756 12.9519 19.2898C10.7405 20.1656 8.88847 21.7606 7.69441 23.8177C7.55941 24.052 7.5229 24.3303 7.59289 24.5915C7.66288 24.8527 7.83364 25.0755 8.06771 25.211C8.30178 25.3464 8.58002 25.3834 8.84136 25.3139C9.10271 25.2444 9.3258 25.0741 9.46169 24.8403C10.2088 23.5469 11.2831 22.4729 12.5767 21.7262C13.8704 20.9795 15.3377 20.5864 16.8314 20.5864C18.3251 20.5864 19.7924 20.9795 21.086 21.7262C22.3797 22.4729 23.454 23.547 24.2011 24.8404C24.3376 25.0728 24.5606 25.2418 24.8213 25.3104C25.0819 25.3791 25.3592 25.3418 25.5925 25.2068C25.8259 25.0718 25.9963 24.85 26.0667 24.5898C26.1371 24.3296 26.1018 24.0521 25.9683 23.8179ZM12.4073 14.1207C12.4073 13.2457 12.6668 12.3904 13.1529 11.6629C13.639 10.9354 14.3299 10.3683 15.1383 10.0335C15.9467 9.69865 16.8362 9.61104 17.6944 9.78174C18.5525 9.95244 19.3408 10.3738 19.9595 10.9925C20.5782 11.6112 20.9995 12.3994 21.1702 13.2576C21.3409 14.1158 21.2533 15.0053 20.9185 15.8136C20.5836 16.622 20.0166 17.3129 19.2891 17.799C18.5616 18.2851 17.7063 18.5446 16.8313 18.5446C15.6584 18.5433 14.5339 18.0768 13.7046 17.2474C12.8752 16.418 12.4087 15.2936 12.4073 14.1207Z" fill={fill}/>
            </svg>
            <Menu
                id="basic-menu"
                style={{width:230}}
                anchorEl={anchorEl}
                open={open}
                onClose={handleClose}
                MenuListProps={{
                'aria-labelledby': 'basic-button',
                }}
            >
                <MenuItem 
                    onClick={()=>{
                            handleClose(); 
                            history('/profile')
                        }
                    }
                >
                    Profile
                </MenuItem>
                <MenuItem 
                    onClick={()=>{
                            handleClose();
                            history('/dev')
                        }
                    }
                >
                    Dev
                </MenuItem>
                <MenuItem 
                    onClick={()=>{
                            logOut();
                            handleClose();
                        }
                    }
                >
                    Logout
                </MenuItem>
            </Menu>
        </div>
        
    )
};

export default UserICon;