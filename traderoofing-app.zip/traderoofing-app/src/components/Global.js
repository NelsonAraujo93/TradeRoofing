var Global = {
    url:"http://localhost:3902/tRoofingApp/",
    ws:"ws://localhost:3902",
    url_front:"http://134.209.142.161:3901/",
    url_images:"http://134.209.142.161:3901/images/",
    /*url:"http://134.209.142.161:3901/esaApp/",
    ws:"ws://134.209.142.161:3901",
    url_front:"http://134.209.142.161:3901/",
    url_images:"http://134.209.142.161:3901/images/",*/
    url_local:"http://134.209.142.161:3901/esaApp/",
    roof_types:[{label:'Shingles'} , {label:'TPO'} , {label:'PVC'} , {label:'Asphalt granulated'} , {label:'EPDM'} , {label:'Metal'}],
    roof_access:[{label:'Ladder'} , {label:'Indoor access'} , {label:'Lock box'} , {label:'On site contact'}],
    request:[{label:'COI'} , {label:'W9'} ],
    services:[{label:'Maintenance'},{label:'Cleaning'},{label:'Repairs'},{label:'Leak investigation'},{label:'Inspection'}]
}

export default Global;