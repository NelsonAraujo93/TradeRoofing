import './NavbarLogged.css';
import React, {Component, useState, useEffect} from 'react';
import {NavLink, useNavigate} from 'react-router-dom';

import Global from '../Global';
import axios from 'axios';
import Swal from 'sweetalert2';
import tfLogoSvg from '../../assets/images/tf-logo.svg';
import { Button } from '@mui/material';

const  NavbarLogged= ({user3}) => {
    const [user, setUser] = useState(user3);
    const url = Global.url;
    const [menu, setMenu] = useState(false);
    const history= useNavigate();

    useEffect(()=>{
        //veryfyUserSesion();
        
        debugger
    },[])
    const logOut = () =>{
        //remove tokenSesion
        localStorage.removeItem('userSesion');
         Swal.fire({
            title: 'Closed session',
            text:'See you soon!',
            confirmButtonText: 'Ok',
        }).then(()=>{
            history('/');
            window.location.reload();
        })
    }
    if(user===undefined){
        return(
            <React.Fragment>
                <div className="navbar-container-logged" 
                    style={{opacity:1}} 
                >
                    <div className="navbarContent">
                        <div className='back-trade'>
                            <Button 
                                className="loginBtn" 
                                variant="contained"
                            >
                                <input type="submit" value="Book for free">
                                    
                                </input>
                            </Button>
                        </div>
                        <div className='login-header-container' style={{cursor:'pointer'}} >

                            <div className='logo-container' >
                                <img className="trade-roofing-logo" src={tfLogoSvg}></img>
                            </div>
                            <div className='logo-text'>Service manager</div>
                        </div>
                        <div className='navbar-links-container'>
                            <div className='user-name-regular'>Welcome, <span className='user-name-bold'>ss</span></div>
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }else{

        return(
            <React.Fragment>
                <div className="navbar-container-logged" 
                    style={{opacity:1}} 
                >
                    <div className="navbarContent">
                        <div className='back-trade'>
                            <Button 
                                className="loginBtn" 
                                variant="contained"
                                onClick={(e)=>{e.preventDefault();  history('/logged-booking');}}
                            >
                                Book for free
                            </Button>
                        </div>
                        <div className='login-header-container'>
    
                            <div className='logo-container'  onClick={()=>{debugger; history('/manager')}}>
                                <img className="trade-roofing-logo" src={tfLogoSvg}></img>
                            </div>
                            <div className='logo-text'>Service manager</div>
                        </div>
                        <div className='navbar-links-container'>
                            <div className='user-name-regular'
                                onClick={(e)=>{
                                    e.preventDefault();
                                    setMenu(!menu);
                                }}
                            >Welcome, <span className='user-name-bold'>{user.name}</span></div>
                            {
                                menu?(
                                    <div className='nav-menu active'>
                                        <div className='nav-menu-item' onClick={(e)=>{e.preventDefault();
                                            logOut();
                                        }}>
                                            Log out
                                        </div>
                                    </div>
                                ):(
                                    <div className='nav-menu'>
                                        <div className='nav-menu-item' onClick={(e)=>{e.preventDefault();
                                            logOut();
                                        }}>
                                            Log out
                                        </div>
                                    </div>
                                )
    
                               
                            }
                        </div>
                    </div>
                </div>
            </React.Fragment>
        )
    }
    
}
export default NavbarLogged;