import './Activate.css';
import React, {Component, useEffect, useState} from 'react';
import axios from 'axios';
import Global from '../Global';
import Swal from 'sweetalert2';
import TextField from '@mui/material/TextField';

import {io} from 'socket.io-client';
import Button from '@mui/material/Button';
import {NavLink, Navigate, useParams, useNavigate } from 'react-router-dom';


//images
import tfLogo from '../../assets/images/tf-logo.png';
import tfLogoSvg from '../../assets/images/tf-logo.svg';
import bgMosaico from '../../assets/images/bg-mosaico.png';



const BgCircle =() =>{
    var width=window.innerWidth;
    return(
        <div style={{width:2154, height:2154}} className="bigCircle">
           
        </div>
    )
}
const Activate=()=>{
    const [name, setName] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const [address, setAddress] = useState('');
    const [city, setCity] = useState('');
    const [state, setState] = useState('');

    const params= useParams();
    const history=useNavigate();

    useEffect(()=>{
        debugger;
        activateAccount(params.id);
    },[])
    const url= Global.url;
    const activateAccount=async(id)=>{
        debugger
        await axios.put(url+'activate-user',{userId:id})
        .then(
            res=>{
                  //Crear Sesion User
                  Swal.fire({
                    title: 'Welcome',
                    icon:'success',
                    text:'Your account is active, log in to use our services',
                    confirmButtonText: 'Ok',
                }).then(()=>{
                    history('/login');
                })
                
            }
        )
        .catch(
            err=>{

            }
        )
    }
    const saveForm =  async () =>{
        var formData= {};
        formData.name=name;
        formData.phoneNumber=phoneNumber;
        formData.address=address;
        formData.city=city;
        formData.state=state;
       
        await axios.put(url+'create-user-second', formData)
            .then( res =>{
                debugger;
                if(res){
                    
                    //Crear Sesion User
                    Swal.fire({
                        title: 'Welcome',
                        text:'Remember to check your news!',
                        confirmButtonText: 'Ok',
                        customClass:'icon-alert'
                    }).then(()=>{
                        localStorage.setItem('userSesion', res.data.token);
                    })
                }else{
                    Swal.fire(
                        {
                            title: 'Error',
                            text:'Wrong email or password.',
                            confirmButtonText: 'Ok',
                            allowOutsideClick: false,
                            showCloseButton: true
                        }
                    )
                }
            }, error =>{
                 Swal.fire(
                    {
                        title: 'Error',
                        text:'Wrong email or password.',
                        confirmButtonText: 'Ok',
                        allowOutsideClick: false,
                        showCloseButton: true
                    }
                )
            })
        
    }
    return(
        <React.Fragment>
            <div className='login-container'>
                <div className='bg-container-mosaico'>
                    <img src={bgMosaico}></img>
                </div>{
                    /**
                     
<div className="content-login">
                    <div className="containerTop">
                        <div className="form-content-container row">
                            <div className='login-header-container'>

                                <div className='logo-container'>
                                    <img className="trade-roofing-logo" src={tfLogoSvg}></img>
                                </div>
                                <div className='logo-text'>Service manager</div>
                            </div>
                            <form className="form" 
                                onSubmit={(e)=>{
                                    e.preventDefault();
                                    saveForm()
                                }
                                        
                                    }>
                                <div className="form-group">
                                    <TextField 
                                        required
                                        className='login-input'
                                        id="outlined-basic-email" 
                                        label="Full name" 
                                        variant="outlined"
                                        fullWidth
                                        inputRef={name}
                                        onChange={(e)=>{e.preventDefault(); setName(e.target.value)}}
                                    />
                                </div>
                                <div className="form-group">
                                    <TextField 
                                        required
                                        id="outlined-basic-pass"
                                        className='login-input'
                                        label="Phone number" 
                                        variant="outlined"
                                        type="numeric"
                                        fullWidth
                                        inputRef={phoneNumber}
                                        onChange={(e)=>{e.preventDefault(); setPhoneNumber(e.target.value)}}
                                    />
                                </div>
                                <div className="form-group">
                                    <TextField 
                                        required
                                        id="outlined-basic-pass"
                                        className='login-input'
                                        label="Address" 
                                        variant="outlined"
                                        type="numeric"
                                        fullWidth
                                        inputRef={address}
                                        onChange={(e)=>{e.preventDefault(); setAddress(e.target.value)}}
                                    />
                                </div>
                                <div className="form-group">
                                    <TextField 
                                        required
                                        id="outlined-basic-pass"
                                        className='login-input'
                                        label="City" 
                                        variant="outlined"
                                        type="numeric"
                                        fullWidth
                                        inputRef={city}
                                        onChange={(e)=>{e.preventDefault(); setCity(e.target.value)}}
                                    />
                                </div>
                                <div className="form-group">
                                    <TextField 
                                        required
                                        id="outlined-basic-pass"
                                        className='login-input'
                                        label="State" 
                                        variant="outlined"
                                        type="numeric"
                                        fullWidth
                                        inputRef={state}
                                        onChange={(e)=>{e.preventDefault(); setState(e.target.value)}}
                                    />
                                </div>
                                <div className="form-group button-bottom">
                                    <Button 
                                        className="loginBtn" 
                                        variant="contained"
                                    >
                                        <input type="submit" value="Login">
                                            
                                        </input>
                                    </Button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>





                     */
                }
                
            </div>
        </React.Fragment>
    )
    
}
export default Activate;