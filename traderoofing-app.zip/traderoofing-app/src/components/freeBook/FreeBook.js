import './FreeBook.css'
import { Autocomplete, Button, IconButton, TextField } from "@mui/material";
import { DatePicker, LocalizationProvider } from "@mui/x-date-pickers";
import React, {useEffect, useState} from "react";
import Navbar from "../navbar/Navbar";
import BackIcon from '../../assets/svg/backIcon'
import { AdapterDateFns } from "@mui/x-date-pickers/AdapterDateFns";


import tfLogoSvg from '../../assets/images/tf-logo.svg';
import bgMosaico from '../../assets/images/bg-mosaico.png';
import ReCAPTCHA from 'react-google-recaptcha';


const FreeBook = ()=>{
    const [registerStep, setRegisterStep] = React.useState(0);

    const saveForm =  async (e) =>{
        /* e.preventDefault();
         var userData = {
             name : this.userNameRef.current.value,
             pass : this.userPassRef.current.value
         }
         if(this.userNameRef.current.value===''){
             this.userNameRef.current.setCustomValidity("Complete este campo");
         }else if(this.userPassRef.current.value===''){
             this.userNameRef.current.setCustomValidity("Complete este campo");
         }
         this.setState({
            user : userData
         })
         await axios.post(this.url+'login', userData)
             .then( res =>{
                 if(res){
                     
                     //Crear Sesion User
                     Swal.fire({
                         title: '<div class="big-square"></div>'+
                         '<div class="little-square"></div>'+
                         '<div class="bg-title-pop"><div class="list-label pop absolute-center"><p>Bienvenido</p></div></div>',
                         confirmButtonText: 'Seguir',
                         allowOutsideClick: false,
                         showCloseButton: true}
                     ).then(()=>{
                         localStorage.setItem('userSesion', res.data.token);
                         this.props.history.push('/news');
                     })
                 }else{
                     Swal.fire(
                         {
                             title: '<div class="big-square"></div>'+
                                     '<div class="little-square"></div>'+
                                     '<div class="bg-title-pop"><div class="list-label pop absolute-center"><p>Usuario o contraseña incorrectos</p></div></div>',
                                     confirmButtonText: 'Seguir',
                                     allowOutsideClick: false,
                                     showCloseButton: true
                         }
                     )
                     this.setState({
                         status:'failed'
                     })
                 }
             }, error =>{
                  Swal.fire(
                     {
                         title: '<div class="big-square"></div>'+
                                 '<div class="little-square"></div>'+
                                 '<div class="bg-title-pop"><div class="list-label pop absolute-center"><p>Usuario o contraseña incorrectos</p></div></div>',
                                 confirmButtonText: 'Seguir',
                                 allowOutsideClick: false,
                                 showCloseButton: true
                     }
                 )
             })*/
         
    }
    const saveStep=(step)=>{
        debugger
        //GuardarVariables
        //Actualizo el step
        setRegisterStep(registerStep+1);
    }
    const onChange=(value) =>{
        console.log("Captcha value:", value);
    }
    const RegisterUser = () => {
        const [fillColorBack, setFillColorBack]= useState(false);
        const [name,setName] = useState('');
        const [textDescription,setTextDescription] = useState('');
        const [mail,setMail] = useState('');
        const [birth,setBirth] = useState(null);
        const [city,setCity] = useState('');
        const [phone,setPhone] = useState('');
        const [id,setId] = useState(0);
        const [referent,setReferent] = useState('');
        const [value, setValue] = React.useState(null);
        const cities = [
            { label:'Cities',id:1000},
            { label: 'Cali', id: 0 },
            { label: 'Medellìn', id: 1 },
            { label: 'Bogotà', id: 2 },
            { label: 'Manizales', id: 3 },
            { label: 'Pereira', id: 4 },
            { label: 'Armenìa', id: 5 },
            { label: 'Buenaventura', id: 6 },
            { label: 'Quìbdo', id: 7 },
            { label: 'Bucaramanga', id: 8 },
            { label: 'Popayan', id: 9 },
            { label: 'Cartagena', id: 10 },
            { label: 'Barranquilla', id: 11 },
            { label: 'Cucuta', id: 12 },
            { label: 'Tunja', id: 13 },
            { label: 'Pasto', id: 14 },
        ]

        useEffect(()=>{
            setCity(cities[0].label);
        },[])
        var step= registerStep;
        return(
            <div className="modal-register">
                {
                    step===0 &&
                    <div className="step step-1">
                        <div className="stepBtn">
                            <div className="back-header">
                            </div>
                        </div>

                        <div className="step-header"> Service form</div>
                        <div className="step-form">
                            <form className="form" onSubmit={saveForm}>
                                <div className="form-content">
                                    <div className="form-group">
                                        <TextField
                                            required
                                            id="outlined-basic"
                                            className='login-input'
                                            label="Full name" 
                                            variant="outlined"
                                            value={name}
                                            onChange={(e)=>{setName(e.target.value)}}
                                            fullWidth
                                        />
                                    </div>
                                    <div className="form-group">
                                        <TextField
                                            required
                                            id="outlined-basic"
                                            className='login-input'
                                            label="Email" 
                                            variant="outlined"
                                            value={mail}
                                            onChange={(e)=>{debugger;setMail(e.target.value)}}
                                            fullWidth
                                        />
                                    </div>
                                    <div className="form-group">
                                        <TextField 
                                            required
                                            id="outlined-basic"
                                            className='login-input'
                                            label="Phone number" 
                                            variant="outlined"
                                            fullWidth
                                            type='numeric'
                                            value={phone}
                                            onChange={(e)=>{debugger;setPhone(e.target.value)}}
                                        />
                                    </div>
                                </div>
                                <div className='step-navigator'>
                                    <div className="step-marker">
                                        <div className="step-mark active"></div>
                                        <div className="step-mark"></div>
                                    </div>
                                    <Button 
                                        className="loginBtn" 
                                        variant="contained"
                                        onClick={()=>{
                                            setRegisterStep(step+1)
                                        }}
                                    >
                                        Next
                                    </Button>
                                </div>

                            </form>
                        </div>
                       
                    </div>
                }
                {
                step===4 &&
                    <div className="step step-2">
                        <div className="stepBtn">
                            <div className="back-header">
                                <div 
                                    className="back-btn" 
                                    onClick={()=>{
                                        setRegisterStep(step-1);
                                    }}>
                                    <IconButton><BackIcon></BackIcon></IconButton>
                                </div>
                            </div>
                        </div>
                        <div className="step-header"> Service form</div>
                        <div className="step-form">
                            <form className="form" onSubmit={saveForm}>
                                <div className="form-content">
                                    <div className="form-group">
                                        <LocalizationProvider dateAdapter={AdapterDateFns}>
                                            <DatePicker
                                                label="Pick a date"
                                                value={birth}
                                                onChange={(newValue) => {
                                                    setBirth(newValue);
                                                }}
                                                renderInput={(params) => <TextField className='login-input' fullWidth {...params} />}
                                            />
                                        </LocalizationProvider>
                                    </div>
                                    <div className="form-group">
                                        <Autocomplete
                                            disablePortal
                                            id="combo-box-demo"
                                            fullWidth
                                            options={cities}
                                            value={city}
                                            onChange={(event, newValue) => {
                                                setCity(newValue);
                                            }}
                                            renderInput={(params) => <TextField className='login-input'   label="City" fullWidth {...params} />}
                                        />
                                    </div>
                                    <div className="form-group">
                                        <TextField 
                                            id="outlined-basic" 
                                            className='login-input'
                                            label="Adress" 
                                            variant="outlined"
                                            fullWidth
                                        />
                                    </div>
                                </div>
                                <div className='step-navigator'>
                                    <div className="step-marker">
                                        <div className="step-mark completed"></div>
                                        <div className="step-mark active"></div>
                                        <div className="step-mark"></div>
                                    </div>
                                    <Button 
                                        className="loginBtn" 
                                        variant="contained"
                                        onClick={()=>{
                                            setRegisterStep(step+1)
                                        }}
                                    >
                                        Next
                                    </Button>
                                </div>
                               

                            </form>
                        </div>
                      
                    </div>
                }
                {
                    step===1 &&
                    <div className="step step-3">
                    <div className="stepBtn">
                        <div className="back-header">
                            <div 
                                className="back-btn" 
                                onClick={()=>{
                                    setRegisterStep(step-1);
                                }}>
                                <IconButton><BackIcon></BackIcon></IconButton>
                            </div>
                        </div>
                    </div>
                    <div className="step-header"> Service form</div>
                    <div className="step-form">
                        <form className="form" onSubmit={saveForm}>
                            <div className="form-content">
                                <div className="form-group area">
                                    <textarea className="text-area-tf" placeholder='Notes' maxLength={250} value={textDescription} onChange={(e)=>{e.preventDefault(); setTextDescription(e.target.value)}} />
                                </div>
                                {
                                    /**
                                     *  <div className="form-group">
                                    <ReCAPTCHA
                                        sitekey="6LclJQkhAAAAAAXUx3mlCKGVrPjKYWFM6M4M-9KL"
                                        onChange={onChange}
                                    />
                                </div>
                                     * 
                                     * 
                                     */
                                }
                               

                            </div>
                            <div className='step-navigator'>
                                <div className="step-marker">
                                    <div className="step-mark complete"></div>
                                    <div className="step-mark active"></div>
                                </div>
                                <Button 
                                    className="loginBtn" 
                                    variant="contained"
                                    onClick={()=>{
                                    //saveForm()
                                    }}
                                >
                                    Send
                                </Button>
                            </div>
                           
                        </form>
                    </div>  
                    </div>
                }
            </div>
        )
    }
    return(
        <React.Fragment>
            
            <div className="container-navbar">
                <Navbar></Navbar>
            </div>
            <div className="free-booking-container">
                <div className='bg-container-mosaico'>
                    <img src={bgMosaico}></img>
                </div>
                <div className="booking-component">
                    <RegisterUser/>
                </div>

            </div>
        </React.Fragment>
    )
}
export default FreeBook;